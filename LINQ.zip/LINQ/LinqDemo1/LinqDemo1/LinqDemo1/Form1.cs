﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LinqDemo1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] games = {"Cricket","Football","Vollyball","Badminton","Basketball","Hockey"};

            //SimpleSelect(games);

            //SelectWithWhere(games);

            //SelectWithExactMatch(games,"Hockey");

            //SelectWithOrder(games);

            //customEmployeeList();

            /*long minSalary = 10000, maxSalary = 18000;
            CustomEmployeeListWithWhere(minSalary,maxSalary);
            */

            int eid = 101;
            CustomEmployeeListWithSingleResult(eid);
        }

        //simple select example
        public static void SimpleSelect(string[] games)
        {
            var list = from g in games
                       select g;

            StringBuilder sb = new StringBuilder();

            foreach (var game in list)
            {
                sb.Append(game + Environment.NewLine);
            }

            MessageBox.Show(sb.ToString(),"SimpleSelect");
        }

        //select with where clause example
        public static void SelectWithWhere(string[] games)
        {
            var list = from g in games
                where g.StartsWith("B")
                select g;

            StringBuilder sb = new StringBuilder();

            foreach (var game in list)
            {
                sb.Append(game + Environment.NewLine);
            }

            MessageBox.Show(sb.ToString(),"SelectWithWhere");
        }

        //select with exact match example

        public static void SelectWithExactMatch(string[] games,string game)
        {
            var list = from g in games
                where g == game
                select g;

            if (list.Contains(game))
            {
                MessageBox.Show(game+" found", "SelectWithExactMatch");
            }
            else
            {
                MessageBox.Show(game+" not found", "SelectWithExactMatch");
            }
        }

        //select with ordered descending list example

        public static void SelectWithOrder(string[] games)
        {
            var list = from g in games
                        orderby g descending
                       select g;

            StringBuilder sb = new StringBuilder();

            foreach (var game in list)
            {
                sb.Append(game + Environment.NewLine);
            }

            MessageBox.Show(sb.ToString(),"Select With Descending Order");
        }

        public void customEmployeeList()
        {
            List<Employee> emp = new List<Employee>();

            Employee e1 = new Employee();
            e1.empid = 101;
            e1.ename = "Gautam";
            e1.salary = 18000;

            Employee e2 = new Employee();
            e2.empid = 102;
            e2.ename = "Shyam";
            e2.salary = 28000;

            Employee e3 = new Employee();
            e3.empid = 103;
            e3.ename = "Ajay";
            e3.salary = 15000;

            Employee e4 = new Employee();
            e4.empid = 104;
            e4.ename = "Anil";
            e4.salary = 8000;

            Employee e5 = new Employee();
            e5.empid = 105;
            e5.ename = "Pujan";
            e5.salary = 15000;

            //Adding objects to emp list

            emp.Add(e1);
            emp.Add(e2);
            emp.Add(e3);
            emp.Add(e4);
            emp.Add(e5);

            var list = from e in emp
                       orderby e.empid
                        select e;

            StringBuilder sb = new StringBuilder();

            foreach (Employee e in list)
            {
                sb.Append(e.empid + " : " + e.ename + " : " + e.salary + Environment.NewLine);
            }

            MessageBox.Show(sb.ToString(),"Employee List");
        }

        public void CustomEmployeeListWithWhere(long minSalary, long maxSalary)
        {
            List<Employee> emp = new List<Employee>();

            Employee e1 = new Employee();
            e1.empid = 101;
            e1.ename = "Gautam";
            e1.salary = 18000;

            Employee e2 = new Employee();
            e2.empid = 102;
            e2.ename = "Shyam";
            e2.salary = 28000;

            Employee e3 = new Employee();
            e3.empid = 103;
            e3.ename = "Ajay";
            e3.salary = 15000;

            Employee e4 = new Employee();
            e4.empid = 104;
            e4.ename = "Anil";
            e4.salary = 8000;

            Employee e5 = new Employee();
            e5.empid = 105;
            e5.ename = "Pujan";
            e5.salary = 15000;

            //Adding objects to emp list

            emp.Add(e1);
            emp.Add(e2);
            emp.Add(e3);
            emp.Add(e4);
            emp.Add(e5);

            var list = from e in emp
                       where e.salary >= minSalary && e.salary <= maxSalary
                       orderby e.empid
                       select e;

            if (list.Any())
            {
                StringBuilder sb = new StringBuilder();

                foreach (Employee e in list)
                {
                    sb.Append(e.empid + " : " + e.ename + " : " + e.salary + Environment.NewLine);
                }
                MessageBox.Show(sb.ToString(),"Employee Salary "+minSalary+" - "+maxSalary);
            }
            else
            {
                MessageBox.Show("No records found !");
            }
        }

        public void CustomEmployeeListWithSingleResult(int eid)
        {
            List<Employee> emp = new List<Employee>();

            Employee e1 = new Employee();
            e1.empid = 101;
            e1.ename = "Gautam";
            e1.salary = 18000;

            Employee e2 = new Employee();
            e2.empid = 102;
            e2.ename = "Shyam";
            e2.salary = 28000;

            Employee e3 = new Employee();
            e3.empid = 103;
            e3.ename = "Ajay";
            e3.salary = 15000;

            Employee e4 = new Employee();
            e4.empid = 104;
            e4.ename = "Anil";
            e4.salary = 8000;

            Employee e5 = new Employee();
            e5.empid = 105;
            e5.ename = "Pujan";
            e5.salary = 15000;

            //Adding objects to emp list

            emp.Add(e1);
            emp.Add(e2);
            emp.Add(e3);
            emp.Add(e4);
            emp.Add(e5);

            try
            {
                var list = (from e in emp
                    where e.empid.Equals(eid)
                    select e).Single<Employee>();
                MessageBox.Show(list.empid + " : " + list.ename + " : " + list.salary, "Single Employee Search");
            }
            catch (Exception e)
            {
                MessageBox.Show("Records not found !");
            }
        }

    }

    public class Employee
    {
        public int empid { get; set; }
        public string ename { get; set; }
        public long salary { get; set; }
    }
}
