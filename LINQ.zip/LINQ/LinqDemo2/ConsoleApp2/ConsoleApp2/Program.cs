﻿using System;
using System.Collections.Generic;
using System.Linq;

internal class Program
{
    private static void Main()
    {
        //Example1();
        //Example2();
        //Example3();
        //Example4();
        //Example5();
        //Example6();
        //Example7();
        //Example8();
        //Example9();
        Example10();
    }

    public static void Example1()
    {
        string[] words = {"hello", "wonderful", "LINQ", "beautiful", "world"};
        //Get only short words
        var shortWords = from word in words
            where word.Length <= 5
            select word;

        //Print each word out
        foreach (var word in shortWords)
        {
            Console.WriteLine(word);
        }
        Console.ReadLine();
    }

    public static void Example2()
    {
        // Specify the data source.
        int[] scores = new int[] {97, 92, 81, 60};

        // Define the query expression.
        IEnumerable<int> scoreQuery = from score in scores
            where score > 80
            select score;

        // Execute the query.
        foreach (int i in scoreQuery)
        {
            Console.Write(i + " ");
        }
        Console.ReadLine();
    }

    public static void Example3()
    {
        List<DepartmentClass> departments = new List<DepartmentClass>();
        departments.Add(new DepartmentClass { DepartmentId = 1, Name = "Account" });
        departments.Add(new DepartmentClass { DepartmentId = 2, Name = "Sales" });
        departments.Add(new DepartmentClass { DepartmentId = 3, Name = "Marketing" });

        List<EmployeeClass> employees = new List<EmployeeClass>();
        employees.Add(new EmployeeClass { DepartmentId = 1, EmployeeId = 1, EmployeeName = "William" });
        employees.Add(new EmployeeClass { DepartmentId = 2, EmployeeId = 2, EmployeeName = "Miley" });
        employees.Add(new EmployeeClass { DepartmentId = 1, EmployeeId = 3, EmployeeName = "Benjamin" });


        var list = (from e in employees
                    join d in departments on e.DepartmentId equals d.DepartmentId
                    select new
                    {
                        EmployeeName = e.EmployeeName,
                        DepartmentName = d.Name
                    });

        foreach (var e in list)
        {
            Console.WriteLine("Employee Name = {0} , Department Name = {1}",
                              e.EmployeeName, e.DepartmentName);
        }

        Console.WriteLine("\nPress any key to continue.");
        Console.ReadKey();
    }

        private class DepartmentClass
        {
            public int DepartmentId { get; set; }
            public string Name { get; set; }
        }

        private class EmployeeClass
        {
            public int EmployeeId { get; set; }
            public string EmployeeName { get; set; }
            public int DepartmentId { get; set; }
        }

    public static void Example4()
    {
        List<string> words = new List<string>() { "an", "apple", "a", "day" };

        var query = from word in words
                    select word.Substring(0, 1);

        foreach (string s in query)
            Console.WriteLine(s);
            Console.ReadLine();
    }

    public static void Example5()
    {
        List<string> phrases = new List<string>() { "an apple a day", "the quick brown fox" };

        var query = from phrase in phrases
                    from word in phrase.Split(' ')
                    select word;

        foreach (string s in query)
            Console.WriteLine(s);
            Console.ReadLine();
    }

    public static void Example6()
    {
        List<int> numbers = new List<int>() { 35, 44, 200, 84, 3987, 4, 199, 329, 446, 208 };

        IEnumerable<IGrouping<int, int>> query = from number in numbers
                                                 group number by number % 2;

        foreach (var group in query)
        {
            Console.WriteLine(group.Key == 0 ? "\nEven numbers:" : "\nOdd numbers:");
            foreach (int i in group)
                Console.WriteLine(i);
        }
        Console.ReadLine();
    }

    public static void Example7()
    {
        Pet[] cats = Pet.GetCats();
        Pet[] dogs = Pet.GetDogs();

        IEnumerable<string> query = cats.Select(cat => cat.Name).Concat(dogs.Select(dog => dog.Name));

        foreach (var e in query)
        {
           Console.WriteLine("Name = {0} ", e);
        }

        Console.WriteLine("\nPress any key to continue.");
        Console.ReadKey();
    }

    class Pet
    {
        public string Name { get; set; }
        public int Age { get; set; }

        public static Pet[] GetCats()
        {
            Pet[] cats = { new Pet { Name="Barley", Age=8 },
                       new Pet { Name="Boots", Age=4 },
                       new Pet { Name="Whiskers", Age=1 } };
            return cats;
        }

        public static Pet[] GetDogs()
        {
            Pet[] dogs = { new Pet { Name="Bounder", Age=3 },
                       new Pet { Name="Snoopy", Age=14 },
                       new Pet { Name="Fido", Age=9 } };
            return dogs;
        }
    }

    public static void Example8()
    {

        Console.WriteLine("Distinct Numbers:-");
        Console.WriteLine("-------------------------------");
        double[] numbers1 = { 2.0, 2.1, 2.2, 2.3, 2.4, 2.5 };
        double[] numbers2 = { 2.2 };

        IEnumerable<double> onlyInFirstSet = numbers1.Except(numbers2);

        foreach (double number in onlyInFirstSet)
            Console.WriteLine(number);
        Console.ReadLine();
    }

    public static void Example9()
    {
        Console.WriteLine("Intersect Example");
        Console.WriteLine("---------------------------");

        int[] id1 = { 44, 26, 92, 30, 71, 38 };
        int[] id2 = { 39, 59, 83, 47, 26, 4, 30 };

        IEnumerable<int> both = id1.Intersect(id2);

        foreach (int id in both)
        Console.WriteLine(id);

        Console.ReadLine();

        Console.WriteLine("Union Example");
        Console.WriteLine("---------------------------");

        int[] ints1 = { 5, 3, 9, 7, 5, 9, 3, 7 };
        int[] ints2 = { 8, 3, 6, 4, 4, 9, 1, 0 };

        IEnumerable<int> union = ints1.Union(ints2);

        foreach (int num in union)
        {
            Console.Write("{0} ", num);
            Console.Write("\n");
        }
        Console.ReadLine();
    }

    public static void Example10()
    {
        Pet barley = new Pet() { Name = "Barley", Age = 4 };
        Pet boots = new Pet() { Name = "Boots", Age = 1 };
        Pet whiskers = new Pet() { Name = "Whiskers", Age = 6 };

        List<Pet> pets1 = new List<Pet>() { barley, boots };
        List<Pet> pets2 = new List<Pet>() { barley, boots };
        List<Pet> pets3 = new List<Pet>() { barley, boots, whiskers };

        bool equal = pets1.SequenceEqual(pets2);
        bool equal3 = pets1.SequenceEqual(pets3);

        Console.WriteLine("The lists pets1 and pets2 {0} equal.", equal ? "are" : "are not");
        Console.WriteLine("The lists pets1 and pets3 {0} equal.", equal3 ? "are" : "are not");

        Console.WriteLine("\nPress any key to continue.");
        Console.ReadKey();
    }
}